<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include_once("../auth/connection/config.php");

// Function to get the user's IP address
function getUserIP() {
    // Check for shared internet/ISP IP
    if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP)) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }

    // Check for IP addresses passing through proxies
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        // Extract a list of IPs (first IP is the client's IP, last is the furthest proxy's IP)
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);

        // Get the first non-local IP
        foreach ($ipList as $ip) {
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }

    // Check for direct IP address
    if (!empty($_SERVER['REMOTE_ADDR']) && filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {
        return $_SERVER['REMOTE_ADDR'];
    }

    // Unable to detect the user's IP address
    return null;
}

// Get the user ID if logged in
$customerId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// If not logged in, use the IP address as a unique identifier
if (!$customerId) {
    $customerId = getUserIP();
}

try {
    // Fetch wishlist count based on the user ID or IP address
    $sqlGetWishlistCount = "SELECT COUNT(*) FROM wishlists WHERE customerId = ?";
    $stmtGetWishlistCount = $connection->prepare($sqlGetWishlistCount);
    $stmtGetWishlistCount->execute([$customerId]);
    $wishlistCount = $stmtGetWishlistCount->fetchColumn();

    $response = ['success' => true, 'count' => $wishlistCount];
    echo json_encode($response);
} catch (Exception $e) {
    // Debug statement to check the SQL error
    echo "SQL Error: " . $e->getMessage();

    $response = ['success' => false, 'message' => 'Error fetching wishlist count: ' . $e->getMessage()];
    echo json_encode($response);
}

$connection = null;
?>
