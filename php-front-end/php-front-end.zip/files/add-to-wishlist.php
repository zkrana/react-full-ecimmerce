<?php
// Include your database connection file
include_once("../auth/connection/config.php");
session_start();

// Retrieve product ID and user ID (if logged in) from the AJAX request
$data = json_decode(file_get_contents("php://input"));
$productId = $data->productId;

// Replace the following line with your actual mechanism to get the user ID
$customerId = isset($_SESSION['userId']) ? $_SESSION['userId'] : null;

// If not logged in, use a unique identifier for the user (e.g., IP address)
function getUserIpAddress() {
    // Check for shared Internet/ISP IP
    if (!empty($_SERVER['HTTP_CLIENT_IP']) && filter_var($_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP)) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }

    // Check for IP addresses passing through proxies
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ipList as $ip) {
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }

    // Check for a public IP address
    if (!empty($_SERVER['HTTP_X_REAL_IP']) && filter_var($_SERVER['HTTP_X_REAL_IP'], FILTER_VALIDATE_IP)) {
        return $_SERVER['HTTP_X_REAL_IP'];
    } elseif (!empty($_SERVER['REMOTE_ADDR']) && filter_var($_SERVER['REMOTE_ADDR'], FILTER_VALIDATE_IP)) {
        return $_SERVER['REMOTE_ADDR'];
    }

    // Fallback: Return localhost address if all else fails
    return '127.0.0.1';
}

// Usage:
$userIdentifier = $customerId ? null : getUserIpAddress();

try {
    $connection->beginTransaction();

    // Fetch product details based on $productId
    $sqlGetProductDetails = "SELECT price FROM products WHERE id = ?";
    $stmtGetProductDetails = $connection->prepare($sqlGetProductDetails);
    $stmtGetProductDetails->execute([$productId]);
    $productDetails = $stmtGetProductDetails->fetch(PDO::FETCH_ASSOC);

    if (!$productDetails) {
        throw new Exception('Product not found');
    }

    // Extract product details
    $productPrice = $productDetails['price'];
    $quantity = 1; // Assuming a constant quantity of 1

    // Set a default value for priority
    $priority = 1;

    // Step 2: Insert a new wishlist record if it doesn't exist for the customer (or null)
    $sqlInsertWishlist = "INSERT IGNORE INTO wishlists (customerId, userIdentifier) VALUES (?, ?)";
    $stmtInsertWishlist = $connection->prepare($sqlInsertWishlist);
    $stmtInsertWishlist->execute([$customerId, $userIdentifier]);

    // Step 3: Get the WishlistID for the customer (or null)
    if ($customerId !== null) {
        $sqlGetWishlistID = "SELECT wishlistId FROM wishlists WHERE customerId = ? AND userIdentifier IS NULL";
    } else {
        $sqlGetWishlistID = "SELECT wishlistId FROM wishlists WHERE userIdentifier = ? AND customerId IS NULL";
    }

    $stmtGetWishlistID = $connection->prepare($sqlGetWishlistID);
    $stmtGetWishlistID->execute([$customerId ?? $userIdentifier]);

    // If the WishlistID exists for the customer, use it; otherwise, insert a new wishlist record
    if ($wishlistId = $stmtGetWishlistID->fetchColumn()) {
        // Step 4: Insert the product into the wishlist_items table
        $sqlInsertWishlistItem = "INSERT INTO wishlist_items (wishlistId, productId, priority, quantity, itemPrice, userIdentifier)
                                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmtInsertWishlistItem = $connection->prepare($sqlInsertWishlistItem);
        $stmtInsertWishlistItem->execute([$wishlistId, $productId, $priority, $quantity, $productPrice, $userIdentifier]);
    }

    $connection->commit();
    echo json_encode(['success' => true, 'message' => 'Product added to wishlist successfully']);
} catch (Exception $e) {
    $connection->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error adding product to wishlist: ' . $e->getMessage()]);
}

// Close the database connection
$connection = null;
?>
