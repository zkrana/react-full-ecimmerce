<div class="mt-14 w-full sm:w-[calc(50%-10px)] lg:w-[calc(33.3333%-21.3333px)]">
    <h4 class="text-lg font-semibold pb-3 border-b border-slate-200 capitalize">
        New arrival
    </h4>
</div>
