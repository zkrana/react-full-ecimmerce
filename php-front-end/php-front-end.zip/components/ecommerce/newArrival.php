<div class=" mt-14 w-full">
    <h4 class="text-lg font-semibold pb-3 border-b border-slate-200 capitalize">
        New arrival
    </h4>
</div>
