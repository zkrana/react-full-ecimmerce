<div class=" mt-14">
    <h4 class="text-lg font-semibold pb-3 border-b border-slate-200 capitalize">
        Deal of The Day
    </h4>
</div>
